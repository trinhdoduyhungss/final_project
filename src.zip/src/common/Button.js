import React from 'react';
import { View, TouchableWithoutFeedback, Text, StyleSheet } from 'react-native'
const Button = (props) => {
    return (
        <View>
            <TouchableWithoutFeedback onPress={props.onPress}>
                <View style={styles.wrapperBtn}>
                    <Text style={styles.nameBtn}>
                        {props.name}
                    </Text>
                </View>
            </TouchableWithoutFeedback>
        </View>
    )
}
const styles = StyleSheet.create({
    nameBtn: {
        borderRadius: 3,
        borderColor: '#777',
        backgroundColor: '#fff',
        borderWidth: 1,
        padding: 5,
        color: '#777',
    },
    wrapperBtn: {
        justifyContent: 'flex-start',
        alignSelf: 'baseline',
        margin: 5,
    }
})
export default Button  