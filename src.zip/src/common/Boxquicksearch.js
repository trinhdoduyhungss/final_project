import React, { Component } from 'react'
import {
    StyleSheet,
    View,
    Text
} from 'react-native';
import Button from '@common/Button';
export default class Boxquicksearch extends Component {
    render() {
        return (
            <View style={{
                flexDirection: 'column',
                marginTop: 6,
                backgroundColor: '#fff'
            }}>
                <Text style={{ margin: 15, color: '#818282' }}>TÌM NHANH</Text>
                <View style={styles.container}>
                    <Button
                        name='tỉnh ủy'
                        onPress={() => this.props.navigation.navigate('Profile')} />
                    <Button
                        name='bà mẹ việt nam anh hùng'
                        onPress={() => this.props.navigation.navigate('Profile')} />
                    <Button
                        name='tai nạn'
                        onPress={() => this.props.navigation.navigate('Profile')} />
                    <Button
                        name='cho biết'
                        onPress={() => this.props.navigation.navigate('Profile')} />
                    <Button
                        name='Vũ Thanh Long'
                        onPress={() => this.props.navigation.navigate('Profile')} />
                    <Button
                        name='Nguyễn Quan Thiệu'
                        onPress={() => this.props.navigation.navigate('Profile')} />
                </View>
            </View>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        marginLeft: 10,
        marginRight: 10,
        marginBottom: 15,
        backgroundColor: '#fff',
        flexWrap: 'wrap' 
    },
    textList: {
        fontSize: 30,
        marginBottom: 20,
        fontWeight: 'bold'
    }
});