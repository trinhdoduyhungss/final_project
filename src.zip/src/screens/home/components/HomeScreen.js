import React, { Component } from 'react';
import {
  View,
  Text,
  Button
} from 'react-native';
import Boxnews from '@common/Boxnews';
import Header from '@common/Header';
// import Button from '@common/Button';
import Boxquicksearch from '@common/Boxquicksearch'


// const renderProduct = (list, onDeleteProduct) =>{
//   return (
//     list.map(product => (
//     <View key={product.id}>
//       <Text key={product.id}>{product.name}</Text> 
//       <Button title='Delete' onPress={()=>onDeleteProduct(product.id)}/>
//     </View>
//     ))
//   )
// }
export default class HomeScreen extends Component {
  render() {
    return (
      <View>
        <Header />        
        {/* {renderProduct(this.props.list, this.props.deleteListProduct)} */}
        <Boxquicksearch navigation={this.props.navigation}/>
        <Boxnews />
      </View>
    );
  }
}

