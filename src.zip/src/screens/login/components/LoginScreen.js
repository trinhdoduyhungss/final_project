import React, { Component } from 'react';
import { 
  StyleSheet, 
  View, 
  Dimensions,
  Button,
  Text,
  TextInput,
  Alert
} from 'react-native';
// import Button from '@common/Button';
import Header from '@common/Header'

// const { width, height } = Dimensions.get('window')
// const renderProduct = (list, onDeleteProduct) =>{
//   return (
//     list.map(product => (<View key={product.user}><Text key={product.id}>{product.pass}</Text> 
//     <Button title='Delete' onPress={()=>onDeleteProduct(product.id)}></Button>
//     </View>
//     ))
//   )
// }

export default class LoginScreen extends Component {
  constructor(props) {
    super(props);
    this.state = { user: '', pass:'' };
    this.Signin = this.Signin.bind(this);
  }
  Signin(login){
    console.log(login.map(test => (test.user)+' '+login.map(test =>(test.pass))));
    const isValidUser = login.findIndex(account => account.user === this.state.user) > -1
    const isValidPass = login.findIndex(account => account.pass === this.state.pass) > -1
    if(isValidUser && isValidPass){
      Alert.alert(
        'Dang nhap thanh cong',
        'Welcome',
        [
          {text: 'OK', onPress: () => console.log('OK Pressed')},
        ],
        { cancelable: false }
      )      
      this.props.navigation.navigate('Home')  
    }else{
      Alert.alert(
        'Dang nhap that bai',
        'Xem lai mat khau hoac user',
        [
          {text: 'Cancel', onPress: () => console.log('Cancel Pressed'), style: 'cancel'},
        ],
        { cancelable: false }
      )
    }
  }
  render() {
    return (
      <View>
        <Header />
        {/* {renderProduct(this.props.list, this.props.deleteListProduct)} */}
        <TextInput
        style={{height: 40, borderColor: 'red', borderWidth: 2}}
        onChangeText={(user) => this.setState({user})}
        placeholder={'nhap user'}
        value={this.state.user}
        />
        <TextInput
        style={{height: 40, borderColor: 'green', borderWidth: 1}}
        onChangeText={(pass) => this.setState({pass})}
        placeholder={'nhap pass'}
        value={this.state.pass}
        />
        <Text />
        <Button title='Login' onPress={()=>this.Signin(this.props.list)}/>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-start',
    alignSelf: 'center',
    marginTop: 30,
    // flexDirection: 'row'
  },
  textList: {
    fontSize: 30,
    marginBottom: 20,
    fontWeight: 'bold'
  }
});