import { connect } from 'react-redux';
import {getListProduct, deleteListProduct} from '@reducers/productReducer';
import LoginScreen from '@login/components/LoginScreen'
const mapStateToProps = state => {
    console.log('state ', state)
    return({
    list: state.products.login
})}
const mapDispatchToProps = dispatch => ({
    getListProduct: () => dispatch(getListProduct()),
    deleteListProduct: (id) => dispatch(deleteListProduct(id))
})
const LoginContainer = connect(mapStateToProps, mapDispatchToProps)(LoginScreen)
export default LoginContainer