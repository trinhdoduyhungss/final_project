import React from 'react'
import iconSearch from '@assets/images/icon-black-search.png'

import { Image, View, TextInput, StyleSheet } from 'react-native'

const SearchInput = (props) => (
  <View style={styles.wrapper}>
    <Image source={iconSearch} />
    <TextInput 
      placeholder="Tìm Kiếm"
      style={styles.textInput} 
      // value={props.value} 
      // onChangeText={(text) => props.onSearch(text)} 
      underlineColorAndroid='transparent'
    />
  </View>
)

const styles = StyleSheet.create({
  wrapper: {
    flexDirection: 'row', 
    backgroundColor: '#005355', 
    padding: 5, 
    borderRadius: 5, 
    alignItems: 'center',
    flex:1
  },
  textInput: {
    paddingLeft: 10, 
    color: '#fff',
    backgroundColor:'#005355',
    flex:1

  }
})

export default SearchInput