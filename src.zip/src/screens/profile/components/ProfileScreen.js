import React, { Component } from 'react';
import { 
  StyleSheet, 
  View, 
  Dimensions,
} from 'react-native';
import Button from '@common/Button';
import Header from '@common/Header'

const { width, height } = Dimensions.get('window')

export default class ProfileScreen extends Component {
 
  render() {
    return (
      <View>
        <Header />
        <Button name='Go to back' onPress={()=>this.props.navigation.goBack()}/>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-start',
    alignSelf: 'center',
    marginTop: 30,
  },
  textList: {
    fontSize: 30,
    marginBottom: 20,
    fontWeight: 'bold'
  }
});