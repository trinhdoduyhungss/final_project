import React, { Component } from 'react'
import {
    StyleSheet,
    View,
    Text
} from 'react-native';
import Application from '@common/Application';
export default class Boxquicksearch extends Component {
    render() {
        return (
            <View style={{
                flexDirection: 'column',
                marginTop: 6,
                backgroundColor: '#fff'
            }}>
                <Text style={{ margin: 15, color: '#818282' }}>NÓNG 24H</Text>
                <View style={styles.container}>
                   <Application /> 
                </View>
            </View>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        marginLeft: 15,
        marginRight: 15,
        marginBottom: 15,
        backgroundColor: '#fff',
    },
    textList: {
        fontSize: 30,
        marginBottom: 20,
        fontWeight: 'bold'
    }
});